import { Routes, Route } from 'react-router-dom'
import Userlist from './components/Userlist'
import Adduser from './components/Adduser'
import Edituser from './components/Edituser'
import Viewuser from './components/Viewuser'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Userlist />} />
      <Route path="/add" element={<Adduser />} />
      <Route path="/edit/:id" element={<Edituser />} />
      <Route path="/view/:id" element={<Viewuser />} />
    </Routes>
  )
}

export default App;

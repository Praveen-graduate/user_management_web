const STORAGE_KEY = 'users'

export const getUsers = () => {
  return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []
}
export const saveUsers = (users) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users))
}
export const addUser = (user) => {
  const users = getUsers()
  users.push(user)
  saveUsers(users)
}
export const updateUser = (id, updatedUser) => {
  const users = getUsers().map(u =>
    u.id === id ? updatedUser : u
  )
  saveUsers(users)
}
export const deleteUser = (id) => {
  const users = getUsers().filter(u => u.id !== id)
  saveUsers(users)
}
export const getUserById = (id) => {
  return getUsers().find(u => u.id === id)
}

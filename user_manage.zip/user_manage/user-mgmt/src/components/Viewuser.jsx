import { useParams, useNavigate } from 'react-router-dom'
import { getUserById } from '../utils/storage'

function Viewuser() {
  const { id } = useParams()
  const navigate = useNavigate()
  const user = getUserById(id)

  if (!user) return <p>User not found</p>

  return (
    <div>
      <h2>User Details</h2>
      <p>Name: {user.name}</p>
      <p>Email: {user.email}</p>
      <p>Role: {user.role}</p>
      <p>Status: {user.status}</p>
      <button onClick={() => navigate('/')}>Back</button>
    </div>
  )
}

export default Viewuser

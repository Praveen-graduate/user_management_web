import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { addUser } from '../utils/storage'

function Adduser() {
  const [user, setUser] = useState({
    name: '',
    email: '',
    role: '',
    status: ''
  })

  const navigate = useNavigate()

  const handleSubmit = (e) => {
    e.preventDefault()

    if (!user.name || !user.email) {
      alert('Name and Email are required')
      return
    }

    if (!/\S+@\S+\.\S+/.test(user.email)) {
      alert('Invalid email format')
      return
    }

    addUser({ ...user, id: Date.now().toString() })
    navigate('/')
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add User</h2>

      <input placeholder="Name"
        onChange={e => setUser({ ...user, name: e.target.value })} />
      <br />

      <input placeholder="Email"
        onChange={e => setUser({ ...user, email: e.target.value })} />
      <br />

      <input placeholder="Role"
        onChange={e => setUser({ ...user, role: e.target.value })} />
      <br />

      <select onChange={e => setUser({ ...user, status: e.target.value })}>
        <option value="">Select Status</option>
        <option>Active</option>
        <option>Inactive</option>
      </select>

      <br /><br />
      <button type="submit">Save</button>
    </form>
  )
}

export default Adduser

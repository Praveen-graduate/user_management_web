import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { getUserById, updateUser } from '../utils/storage'

function Edituser() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [user, setUser] = useState({})

  useEffect(() => {
    setUser(getUserById(id))
  }, [id])

  const handleSubmit = (e) => {
    e.preventDefault()
    updateUser(id, user)
    navigate('/')
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>Edit User</h2>

      <input value={user?.name || ''}
        onChange={e => setUser({ ...user, name: e.target.value })} />
      <br />

      <input value={user?.email || ''}
        onChange={e => setUser({ ...user, email: e.target.value })} />
      <br />

      <input value={user?.role || ''}
        onChange={e => setUser({ ...user, role: e.target.value })} />
      <br />

      <select value={user?.status || ''}
        onChange={e => setUser({ ...user, status: e.target.value })}>
        <option>Active</option>
        <option>Inactive</option>
      </select>

      <br /><br />
      <button type="submit">Update</button>
    </form>
  )
}

export default Edituser
